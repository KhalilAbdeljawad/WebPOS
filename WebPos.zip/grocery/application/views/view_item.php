<?php
/**
 * Created by PhpStorm.
 * User: Khalil
 * Date: 9/7/2016
 * Time: 3:02 AM
 */

//include "header.php";
?>

<iframe style="width: 100%; height: 550px; border: 0px;overflow: hidden;" src="<?php print base_url()."Crud/item"?>" />