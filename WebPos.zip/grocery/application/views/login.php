<?php


?>



<html>
<head>
    <title>Login</title>
</head>

<body dir="rtl">
<br /><br /><br /><br /><br /><br /><br /><br /><br />
<br />
<center>
    <form action="login/login" method="post">
        <table border="0"  style="border:5px solid slateblue;padding: 15px;">
            <tr>
                <td>اسم المستخدم</td>
                <td><input type="text" name="username" value="admin" /> </td>
            </tr>
            <tr>
                <td>كلمة المرور</td>
                <td><input type="password" name="pass" value="admin"/></td>
            </tr>

            <tr>
                <td style="text-align: center" colspan="2"><input type="submit" value="دخول" /> </td>
            </tr>



        </table>


    </form>
</center>

</body>
</html>
